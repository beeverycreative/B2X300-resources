
var os = require('os')


function showScreen(document, screen) {
    hideScreens(document);
    hideButtons(document);
    document.getElementById('screen_'+screen).style.display = 'block';
}

function showButton(document, but) {
    document.getElementById('but_'+but).style.opacity = '1';
    document.getElementById('but_'+but).style.display = 'block';
}

function hideScreens(document) {
    document.getElementById('screen_00').style.display = 'none';
    document.getElementById('screen_01').style.display = 'none';
    document.getElementById('screen_02').style.display = 'none';
    document.getElementById('screen_03').style.display = 'none';
    document.getElementById('screen_04').style.display = 'none';
    document.getElementById('screen_05').style.display = 'none';
    document.getElementById('screen_05B').style.display = 'none';
    document.getElementById('screen_06').style.display = 'none';
    document.getElementById('screen_07').style.display = 'none';
    /*
    document.getElementById('screen_06').style.display = 'none';
    document.getElementById('screen_07').style.display = 'none';
    document.getElementById('screen_08').style.display = 'none';
    document.getElementById('screen_09').style.display = 'none';
    document.getElementById('screen_10').style.display = 'none';
    document.getElementById('screen_11').style.display = 'none';
    */
}

function hideButtons(document) {
    //document.getElementById('but_mid').style.display = 'none';
    //document.getElementById('but_left').style.display = 'none';
    //document.getElementById('but_right').style.display = 'none';
    document.getElementById('but_mid').style.opacity = '0.0';
    document.getElementById('but_left').style.opacity = '0.0';
    document.getElementById('but_right').style.opacity = '0.0';
    document.getElementById('but_mid').onclick = null;//function () {return false}
    document.getElementById('but_left').onclick = null;//function () {return false}
    document.getElementById('but_right').onclick = null;//function () {return false}
    document.getElementById('but_mid').style.cursor = "default";
    document.getElementById('but_left').style.cursor = "default";
    document.getElementById('but_right').style.cursor = "default";

}

function hideAll(document) {
    hideScreens(document);
    hideButtons(document);
}

function registerDrag(step) {
    var holder = document.getElementById('body');
    console.log("STEP: " + step)
    console.log("registering drag on " + holder)
    holder.ondragover = () => {
        document.getElementById('drag_logo').style.color="#777777";
        return false;
    }
    holder.ondragleave = () => {
        document.getElementById('drag_logo').style.color="#c6c6c6";
        return false;
    }
    holder.ondragend = () => {return false;}
    holder.ondrop = (e) => {
        e.preventDefault();
        var path = require('path')
        for (let f of e.dataTransfer.files) {
            console.log("Files you dragged: ", f.path)
            // check extension
            console.log(path.extname(f.path))
            if (path.extname(f.path).toLowerCase() == ".hex") {
                console.log("GOOD")
                document.getElementById('drag_logo').style.color="#3b7508";
                document.getElementById('file_p').innerHTML = "Selected file: " + path.basename(f.path)
                console.log("STEP: " + step)
                showButton(document, 'right')
                document.getElementById('but_right').onclick = function () {
                    // copy file to "marlin.hex"
                    filename = f.path
                    unRegisterDrag()
                    backgroundProcess(step+1, document)
                }
            } else {
                document.getElementById('drag_logo').style.color="#960707";
                document.getElementById('file_p').innerHTML = "Bad file extension: " + path.extname(f.path).toLowerCase()
                document.getElementById('but_right').style.display = 'none';
            }
        }
        return false;
    }
}

function unRegisterDrag() {
    var holder = document.getElementById('body');
    console.log("unregistering drag on " + holder)
    holder.ondragover = () => {return false;}
    holder.ondragleave = () => {return false;}
    holder.ondragend = () => {return false;}
    holder.ondrop = (e) => {return false;}
}

function getLastCommitDate() {
    console.log("getLastCommitDate")
    private_token = "T8QoYSMwwSJi6Xrh2ZwE"
    base_url = "http://beevc.beeverycreative.com:8000"
    url = base_url+"/api/v4/projects/REDSOFT%2FMarlinBEE/jobs/?scope[]=success&per_page=100&private_token=" + private_token //64/artifacts/build/Marlin.ino.with_bootloader.hex"
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url, false);
    xhr.send(null)
    //xhr.responseType = 'json';
    if (xhr.status === 200) {
        console.log("lastCommit - " + "STATUS: " + status)
        //console.log(xhr.response)

        jobs = JSON.parse(xhr.response)
        console.log(jobs)
        job = ""
        size = 0
        downloaded = 0
        for (i=0; i<jobs.length;i++) {
            console.log(i)
            console.log(jobs[i])
            if (i> 100) {break;}
            if (jobs[i].ref == BRANCH && jobs[i].hasOwnProperty('artifacts_file') && jobs[i].artifacts_file.hasOwnProperty('filename')) {
                console.log("ARTIFACTS! " + jobs[i].artifacts_file.filename + " ID: " + jobs[i].id);
                job = jobs[i].id
                console.log("DONE: " + jobs[i].commit.created_at)
                return  jobs[i].commit.created_at
                break;
            }

        }
    }
}
/**************************************************************************/

/*****
* If app stops working, check the private_token expiring date!
****/

comport = ""  //make it global
platform = ""
gotodragndrop = false
filename = ""
job_ref =  ""
job_date = ""
job_id   = ""
BRANCH = 'master'
clicks_until_debug=10

unRegisterDrag()

// enable debug mode!
document.getElementById('bee_logo').onclick = function () {
    clicks_until_debug = clicks_until_debug -1;
    if (clicks_until_debug <= 0) {
        document.getElementById('debug_flag').style.display = 'block';
        BRANCH = 'dev'
    }
}

function backgroundProcess(step=0, document) {
    hideScreens(document)
    hideButtons(document)

    switch(step) {
        case 1:
            // clear contents and display welcome text
            showScreen(document,'01')
            //showButton(document, 'mid')
            document.getElementById('but_mid').onclick = function () {
                backgroundProcess(7, document)
                document.getElementById('online_p').innerHTML = ""
                document.getElementById('online_p0').innerHTML = "Checking webserver connection..."
            }

            // check online status before proceeding
            var xhr = new XMLHttpRequest();
            //xhr.open('GET', "https://beeverycreative.com", true);
            xhr.open('GET', "http://beevc.beeverycreative.com:8000/", true);
            xhr.send();
            ready = false;
            xhr.onreadystatechange = function (e) {
                console.log("XHR" + xhr.readyState)
                if (xhr.readyState == 4 && xhr.status == 200) {
                    ready = true
                    showButton(document, 'mid')
                    document.getElementById('online_p').innerHTML = "When you're ready, click \"OK\"";
                    document.getElementById('online_p0').innerHTML = "<i class='material-icons icon' style='font-size: 80px'>wifi</i><i class='material-icons icon' style='font-size: 40px;color:#235e1b'>check_circle</i>"
                    document.getElementById('loading').style.display = "none"
                }

                if (xhr.readyState == 4 && xhr.status != 200) {
                    ready = true
                    showButton(document, 'mid')
                    document.getElementById('but_mid').onclick = function () {
                        backgroundProcess(99, document)
                    }
                    document.getElementById('online_p').innerHTML = "Can't connect to webserver, please restart application and try again.";
                    document.getElementById('online_p0').innerHTML = "<i class='material-icons icon' style='font-size: 80px'>wifi_off</i>"
                    document.getElementById('loading').style.display = "none"
                }
            }
            break;

        case 7:
            // FIXME: flow is not linear -_-
            showScreen(document, '07')
            //document.getElementById('usb_p').innerHTML = "B2X300 printer found on port " + comport
            showButton(document, 'right')
            showButton(document, 'left')
            document.getElementById('but_right').onclick = function () {backgroundProcess(2, document)}
            document.getElementById('but_left').onclick =  function () {backgroundProcess(1, document)}

            /*** check for update ***/
            //setTimeout(function() {console.log('.')}, 800)

            // 1. check if fwversion exists
            var fs = require('fs');
            fwversion_file = 'fwversion'
            if (fs.existsSync(fwversion_file) == false) {
                // the first you run the app, ask the user to update
                document.getElementById('last_update').innerHTML += "<li><span style='color:#4b7e18'>There is a new firmware update available!</span>"

                let fwnotification = new Notification('B2X300 Firmware Updater', {body: 'There is a new firmware update available!'})
                fwnotification.onclick = () => {
                    console.log('Notification clicked')
                    const remote = require('electron').remote
                    const win = remote.getCurrentWindow()
                    win.focus()
                }
            } else {
                console.log("fwversion exists!")
                // 2. report for how long the printer hasn't been updated
                var linearray = fs.readFileSync(fwversion_file).toString().split("\n");
                var date_commit = new Date(linearray[2])
                var date_today  = Date.now()
                console.log("commit: " + date_commit)
                console.log("today: " + date_today)
                var date_diff = Math.ceil((date_today-date_commit) / (1000 * 3600 * 24))
                day_str = (date_diff == 1) ? "day" : "days"
                document.getElementById('last_update').innerHTML = "<p>The firmware version on your printer is " + date_diff + " " + day_str + " old.</p>"

                // 3. check date of last commit to repo
                private_token = "T8QoYSMwwSJi6Xrh2ZwE"
                base_url = "http://beevc.beeverycreative.com:8000"
                url = base_url+"/api/v4/projects/REDSOFT%2FMarlinBEE/jobs/?scope[]=success&per_page=100&private_token=" + private_token //64/artifacts/build/Marlin.ino.with_bootloader.hex"
                var xhr = new XMLHttpRequest();
                xhr.open('GET', url, true);
                xhr.send()
                xhr.onreadystatechange = function(e) {
                    //xhr.responseType = 'json';
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        console.log("XHR" + xhr.readyState)
                        jobs = JSON.parse(xhr.response)
                        console.log(jobs)
                        job = ""
                        size = 0
                        downloaded = 0
                        for (i=0; i<jobs.length;i++) {
                            if (i> 10) {break;}    // set a limit
                            if (jobs[i].ref == BRANCH && jobs[i].hasOwnProperty('artifacts_file') && jobs[i].artifacts_file.hasOwnProperty('filename')) {
                                job = jobs[i].id
                                last_commit_date = new Date(jobs[i].commit.created_at)
                                // 4. report that there is a new commit available
                                if (Math.abs(last_commit_date/(1000 * 3600 * 24) - date_commit/(1000 * 3600 * 24)) >= 1) {
                                    document.getElementById('last_update').innerHTML += "<p><span style='color:#4b7e18'>There is a new firmware update available!</span></p>"

                                    let fwnotification = new Notification('B2X300 Firmware Updater', {body: 'There is a new firmware update available!'})
                                    fwnotification.onclick = () => {
                                        console.log('Notification clicked')
                                        const remote = require('electron').remote
                                        const win = remote.getCurrentWindow()
                                        win.focus()
                                    }
                                    break;  // stop on first find
                                }
                            }
                        }
                    }
                }
            }


            // check app date
            app_date_file = 'commit_date'
            var app_date = fs.readFileSync(app_date_file).toString().split("\n");  // i'm assuming this always works...
            app_date = new Date(app_date[0])
            var date2_today  = Date.now()
            console.log(app_date)

            private_token = "T8QoYSMwwSJi6Xrh2ZwE"
            base_url = "http://beevc.beeverycreative.com:8000"
            url = base_url+"/api/v4/projects/REDTRON%2Fmarlin-updater/jobs/?scope[]=success&per_page=100&private_token=" + private_token //64/artifacts/build/Marlin.ino.with_bootloader.hex"
            var xhr2 = new XMLHttpRequest();
            xhr2.open('GET', url, true);
            xhr2.send()
            xhr2.onreadystatechange = function(e) {
                if (xhr2.readyState == 4 && xhr2.status == 200) {
                    console.log("XHR" + xhr2.readyState)
                    console.log(JSON.parse(xhr2.response))
                    app_jobs = JSON.parse(xhr2.response)

                    platform_build_name = ""
                    // check platform
                    if (os.platform() == 'linux') {platform_build_name = "build-linux"}
                    if (os.platform() == 'darwin') {platform_build_name = "build-mac"}
                    if (os.platform() == 'win32') {platform_build_name = "build-windows"}

                    for (i=0; i<app_jobs.length; i++) {
                        if (i > 25) {break;}    // limit
                        if (app_jobs[i].ref == BRANCH && app_jobs[i].name == platform_build_name && app_jobs[i].hasOwnProperty('artifacts_file') && app_jobs[i].artifacts_file.hasOwnProperty('filename')) {
                            app_job = app_jobs[i].id
                            app_commit_date = new Date(app_jobs[i].commit.created_at)
                            if (Math.abs(app_commit_date/(1000 * 3600 * 24) - date2_today/(1000 * 3600 * 24)) >= 1) {
                                document.getElementById('app_update').innerHTML += "<br><p>There is a new update ready for this application, click below to download.</p>"
                                document.getElementById('but_dl').style.display ='block'
                                document.getElementById('but_dl').onclick = function () {
                                    //app_download_url =  base_url+"/REDTRON/marlin-updater/-/jobs/"+app_job+"/artifacts/raw/"+platform_build_name+"/"+app_jobs[i].artifacts_file.filename+"?private_token=" + private_token
                                    app_download_url =  base_url+"/REDTRON/marlin-updater/-/jobs/"+app_job+"/artifacts/download?private_token=" + private_token
                                    download_window = window.open(app_download_url,"", "width=100, height=100;")
                                    console.log(app_download_url)


                                }
                                let appnotification = new Notification('B2X300 Firmware Updater', {body: 'There is a new update available for this application!'})
                                appnotification.onclick = () => {
                                    console.log('Notification clicked')
                                    const remote = require('electron').remote
                                    const win = remote.getCurrentWindow()
                                    win.focus()
                                }
                                break;  // stop on first find
                            }
                        }
                    }
                }
            }


            break;

        case 2:
            showScreen(document, '02')
            document.getElementById('but_op01').style.display="block"
            document.getElementById('but_op02').style.display="block"

            document.getElementById('but_op01').onclick =  function () {backgroundProcess(step+1, document); gotodragndrop=false} //continue
            document.getElementById('but_op02').onclick =  function () {backgroundProcess(step+1, document); gotodragndrop=true}
            break;

        case 3:
            // display next screen
            showScreen(document,'03')
            showButton(document, 'right')
            showButton(document, 'left')
            document.getElementById('but_right').onclick = function () {backgroundProcess(step+1, document)}
            document.getElementById('but_left').onclick =  function () {backgroundProcess(step-1, document)}
            platform = os.platform()
            platform_name = ""
            if (platform == "win32") {platform_name = "Windows"}
            if (platform == "linux") {platform_name = "Linux"}
            if (platform == "darwin") {platform_name = "Mac"}
            document.getElementById('os_p').innerHTML = "Your OS: " + platform_name + "."
            break;

        case 4:
            showScreen(document,'04')

            //0403:6001
            vid = "0403"
            pid = "6001"
            delay = 1000

            if (platform == 'win32') {
                const { spawn } = require('child_process');
                //const findcom = spawn('bin\\win\\mode.bat');
                const findcom = spawn('mode');

                findcom.stdout.on('data', (data) => {
                    console.log(`stdout: ${data}`);
                    //comport = String(data).split(' ')[0]
                    //console.log("COMPORT: "+comport)
                    res = String(data).split(' ')

                    for (j=0; j< res.length; j++) {
                        console.log(j + " - " + res[j])
                        if (res[j].includes('COM')==true) {
                            console.log("FOUND!")
                            comport = String(res[j]).split(":")[0]
                            console.log("Comport: " + comport)
                            break;
                        }
                    }

                });

                findcom.stderr.on('data', (data) => {
                    console.log(`stderr: ${data}`);
                });

                findcom.on('close', (code) => {
                    console.log(`child process exited with code ${code}`);
                    console.log(code)
                })

            } else {
                var serialport = require('serialport');
                //console.log(serialport.list)
                serialport.list(function(err, ports) {
                    //console.log(ports)
                    for (i=0; i<ports.length; i++) {
                        //console.log(ports[i])
                        if (ports[i].manufacturer == "FTDI" && ports[i].vendorId == vid && ports[i].productId == pid) {
                            console.log(ports[i].comName)
                            comport = ports[i].comName
                        }
                    }
                })
            }

            setTimeout(function() {
                if (comport != "") {
                    document.getElementById('usb_p').innerHTML = "B2X300 printer found on port " + comport
                    showButton(document, 'right')
                    showButton(document, 'left')
                    document.getElementById('but_right').onclick = function () {backgroundProcess(step+1, document)}
                    document.getElementById('but_left').onclick =  function () {backgroundProcess(step-1, document)}
                } else {
                    document.getElementById('usb_p').innerHTML = "B2X300 printer not found."
                    showButton(document, 'mid')
                    document.getElementById('but_mid').onclick = function () {backgroundProcess(99, document)}
                }
            }, delay);
            break;

        case 5:
            if (gotodragndrop==false) {
                showScreen(document, '05')
                /*****
                * If we're going to use GitLab CI/CD we need to make sure that there's at least one build available -> this is solved by regularly tagging commits and marking them for KEEP
                * Alternatively, we can use beeverycreative.com/public but that's not really flexible
                ****/

                private_token = "T8QoYSMwwSJi6Xrh2ZwE"
                base_url = "http://beevc.beeverycreative.com:8000"
                //url = "http://beegitlab.westeurope.cloudapp.azure.com/api/v4/projects/REDSOFT%2FMarlinBEE/jobs/?scope[]=success&per_page=100&private_token=" + private_token //64/artifacts/build/Marlin.ino.with_bootloader.hex"
                url = base_url+"/api/v4/projects/REDSOFT%2FMarlinBEE/jobs/?scope[]=success&per_page=100&private_token=" + private_token //64/artifacts/build/Marlin.ino.with_bootloader.hex"
                var xhr = new XMLHttpRequest();
                xhr.open('GET', url, true);
                xhr.responseType = 'json';
                xhr.onload = function() {
                    var status = xhr.status;
                    if (status === 200) {
                        console.log("STATUS: " + status)
                        console.log(xhr.response)

                        jobs = xhr.response
                        job = ""
                        size = 0
                        downloaded = 0
                        for (i=0; i<jobs.length;i++) {
                            //console.log(i)
                            if (jobs[i].ref == BRANCH && jobs[i].hasOwnProperty('artifacts_file') && jobs[i].artifacts_file.hasOwnProperty('filename')) {
                                console.log("ARTIFACTS! " + jobs[i].artifacts_file.filename + " ID: " + jobs[i].id);
                                job = jobs[i].id
                                console.log("JOB: " + job)
                                document.getElementById('download_info').innerHTML = jobs[i].ref + " @ " + jobs[i].commit.short_id + " (" + jobs[i].commit.created_at + ")"
                                job_ref =  jobs[i].ref
                                job_date = jobs[i].commit.short_id
                                job_id   = jobs[i].commit.created_at
                                break;  // stop on first successful result
                            }
                        }
                        if (job != "") {
                            // download
                            const fs = require('fs');
                            var request = require('request');
                            // add automatic daily build
                            file_url = base_url+"/REDSOFT/MarlinBEE/-/jobs/"+job+"/artifacts/raw/Marlin.ino.with_bootloader.hex?private_token=" + private_token
                            console.log("DOWNLOAD: " + file_url)
                            console.log("CWD: " + process.cwd())
                            console.log("resourcepath: " + process.resourcesPath)
                            console.log("execpath: " + process.execPath)
                            var out = fs.createWriteStream('marlin.hex');
                            var req = request({
                                method: 'GET',
                                uri: file_url
                            });

                            //size = parseInt(req.headers['content-length'], 10);
                            console.log(req.headers)

                            req.pipe(out);
                            req.on('data', function (chunk) {
                                //  console.log(chunk.length/size*100 + "%");
                                downloaded = downloaded + chunk.length
                                console.log(downloaded + "/" + size)
                            });

                            req.on('end', function() {
                                console.log("FILE DOWNLOADED")
                                document.getElementById('download_logo').style.color="#235e1b"
                                document.getElementById('download_p').innerHTML = "Press \"OK\" to flash the firmware."
                                showButton(document, 'mid')
                                document.getElementById('but_mid').onclick = function () {
                                    filename = "marlin.hex"
                                    backgroundProcess(step+1, document)
                                }
                            });
                        } else {
                            // repeated code
                            document.getElementById('bar_main').style.display = 'none'
                            document.getElementById('download_p').innerHTML = "Can't download firmware. Press \"OK\" to quit."
                            showButton(document, 'mid')
                            document.getElementById('but_mid').onclick = function () {backgroundProcess(99, document)}
                        }
                    } else {
                        console.log("STATUS: " + "ERR")
                        //callback(status, xhr.response);
                        document.getElementById('bar_main').style.display = 'none'
                        document.getElementById('download_p').innerHTML = "Can't download firmware. Press \"OK\" to quit."
                        showButton(document, 'mid')
                        document.getElementById('but_mid').onclick = function () {backgroundProcess(99, document)}
                    }
                };
                xhr.send();
            } else {
                showScreen(document, '05B')
                registerDrag(step); // EVERYTHING HAPPENS HERE!
                //showButton(document, 'right')
                showButton(document, 'left')
                //document.getElementById('but_right').onclick = function () {backgroundProcess(step+1, document)}
                document.getElementById('but_left').onclick =  function () {
                    document.getElementById('drag_logo').style.color="#c6c6c6";
                    document.getElementById('file_p').innerHTML = ""
                    backgroundProcess(step-1, document);
                }
            }

            break;

        case 6:
            showScreen(document, '06')
            console.log("FLASHING: "+filename)
            // sudo avrdude -v -patmega2560 -P/dev/ttyUSB0 -b115200 -D -cwiring -Uflash:w:Marlin.ino.with_bootloader.hex:i
            document.getElementById('flash_logo').style.display = "none"

            const { spawn } = require('child_process');
            avrdude = ""
            avrconf = ""

            if (platform == "linux") {
                avrdude = process.resourcesPath + '/' + 'bin/linux/avrdude'
                avrconf = process.resourcesPath + '/' + 'bin/avrdude.conf'
                filename = process.cwd() + '/' + filename
            }

            if (platform == "win32") {
                avrdude = process.resourcesPath +'\\'+'bin\\win\\avrdude.exe'
                avrconf = process.resourcesPath +'\\'+'bin\\avrdude.conf'
                filename = process.cwd() + '\\' + filename
            }
            if (platform == "darwin") {
                avrdude = process.resourcesPath + '/' + 'resources/bin/mac/avrdude'
                avrconf = process.resourcesPath + '/' + 'resources/bin/avrdude.conf'
                filename = process.cwd() + '/' + filename
            }

            console.log(platform)
            console.log(avrdude)

            // debug
            console.log(process.env)

            const avr_flash = spawn(avrdude, ['-v', '-patmega2560', '-P'+comport, '-b115200', '-D', '-V', '-cavrispmkII', '-C'+avrconf, '-Uflash:w:'+filename+':i'])    // adding -V cuts upload time in half


            console.log(comport)
            console.log(avr_flash)

            avr_flash.stdout.on('data', (data) => {
                console.log(`stdout: ${data}`);
            });

            avr_flash.stderr.on('data', (data) => {
                console.log(`stderr: ${data}`);
            });

            avr_flash.on('close', (code) => {
                console.log(`child process exited with code ${code}`);
                console.log(code)
                if (code == 0) {
                    // successful

                    // write last update info to file
                    var fs = require('fs');
                    try {
                        fs.writeFileSync('fwversion', job_ref +"\n" + job_date + "\n" + job_id, 'utf-8');
                    }
                    catch(e) { alert('Failed to save the file !'); }


                    document.getElementById('flash_logo').style.color = "#235e1b"
                    document.getElementById('flash_logo').style.display = "block"
                    document.getElementById('loading_f').style.display = "none"
                    document.getElementById('flash_p').innerHTML = "Your B2X300 is updated! <br>Press \"Done\" to quit."
                    showButton(document, 'mid')
                    document.getElementById('but_mid').innerHTML = "Done"
                    document.getElementById('but_mid').onclick = function () {backgroundProcess(99, document)}
                } else {
                    // unsuccessful
                    document.getElementById('flash_logo').style.color = "#850808"
                    document.getElementById('flash_logo').style.display = "block"
                    document.getElementById('loading_f').style.display = "none"
                    document.getElementById('flash_p').innerHTML = "Something is wrong, the update didn't finish correctly. <br>Press \"Done\" to quit."
                    showButton(document, 'mid')
                    document.getElementById('but_mid').innerHTML = "Done"
                    document.getElementById('but_mid').onclick = function () {backgroundProcess(99, document)}
                }
            });

            break;

        case 10:
            break;

        case 99:
        const remote = require('electron').remote
        let w = remote.getCurrentWindow()
        w.close()
        break;

        default:
        console.log("Unknown state: " + step)
    }
}
