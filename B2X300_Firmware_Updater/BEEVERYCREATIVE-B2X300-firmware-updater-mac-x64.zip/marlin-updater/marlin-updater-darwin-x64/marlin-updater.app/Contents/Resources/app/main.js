const {app, BrowserWindow} = require('electron')


function createWindow() {
  DEBUG = false;

  if (DEBUG == true) {
      win = new BrowserWindow({width: 1200, height: 600})
  } else {
      win = new BrowserWindow({width: 800, height: 600})
  }
  win.loadFile('index.html')
  win.setResizable(false)
  if (DEBUG == true) {  win.webContents.openDevTools() }
}


console.log(app.getAppPath());

app.on('ready', createWindow)
